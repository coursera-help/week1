@outputSchema("f_readings:{(year:int, distance:float, cycles:float, bikes:float, cars:float, buses:float, vans:float, trucks:float)}")
def convDist(dist):
	year, distance, cycles, bikes, cars, buses, vans, trucks = dist.split(',')
	#print("hey", houseprice)
	distance_f = float(distance)/0.62
	cycles_f = float(cycles)/0.62
	bikes_f = float(bikes)/0.62
	cars_f = float(cars)/0.62
	buses_f = float(buses)/0.62
	vans_f = float(vans)/0.62
	trucks_f = float(trucks)/0.62
	return year, distance_f, cycles_f, bikes_f, cars_f, buses_f, vans_f, trucks_f
