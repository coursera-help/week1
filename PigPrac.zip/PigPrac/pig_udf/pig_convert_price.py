@outputSchema("house_readings:{(cityCat:chararray, rainfall:int, houseprice:int)}")
def dollar(hprices):
	cityCat, rainfall, houseprice = hprices.split(',')
	#print("hey", houseprice)
	houseprice_dollar = float(houseprice)/60
	rainfall_inches=float(rainfall)/25.4
	return cityCat, rainfall_inches, houseprice_dollar
