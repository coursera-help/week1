@outputSchema("f_readings:{(year:int, month:int, maxtemp:float, mintemp:float, frostdays:int, rainfall:float,  sunshinehours:chararray)}")
def convTemp(temp):
	year, month, maxtemp, mintemp, frostdays, rainfall, sunshine = temp.split(',')
	#print("hey", houseprice)
	maxtemp_f = float(maxtemp)*9/5 + 32
	mintemp_f=float(mintemp)*9/5 + 32
	return year, month, maxtemp_f, mintemp_f, frostdays, rainfall, sunshine
	
	
	
